package com.example.shivams.udacityassignmentstage1.model;

public class TrailerDetails {
    private String mId;
    private String mKey;



    public String getmId() {
        return mId;
    }

    public void setmId(String mId) {
        this.mId = mId;
    }

    public String getmKey() {
        return mKey;
    }

    public void setmKey(String mKey) {
        this.mKey = mKey;
    }
}
